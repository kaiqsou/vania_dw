﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProjetoMongoDB.Models;

namespace ProjetoMongoDB.Data
{
    public class ProjetoMongoDBContext : DbContext
    {
        public ProjetoMongoDBContext (DbContextOptions<ProjetoMongoDBContext> options)
            : base(options)
        {
        }

        public DbSet<ProjetoMongoDB.Models.Evento> Evento { get; set; } = default!;
    }
}
